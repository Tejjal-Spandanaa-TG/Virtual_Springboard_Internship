import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from wordcloud import WordCloud
import numpy as np
from textblob import TextBlob

# ============================
# ReviewSense – Milestone 4
# Interactive Customer Feedback Dashboard
# ============================

# Page configuration
st.set_page_config(
    page_title="ReviewSense Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Session State for Authentication ──
if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False
if "username" not in st.session_state:
    st.session_state["username"] = ""

# ── Load Data ──
@st.cache_data
def load_data():
    try:
        df = pd.read_csv("Milestone2_Sentiment_Results_new.csv")
    except Exception:
        df = pd.DataFrame()
        return df
    
    if "sentiment" in df.columns:
        df["sentiment"] = df["sentiment"].str.lower().str.strip()
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
    return df

@st.cache_data
def load_keywords():
    """Load keywords CSV, supporting both plain and marked formats."""
    try:
        keywords_df = pd.read_csv("Milestone3_Keyword_Insights.csv")
        if "keyword" in keywords_df.columns and "frequency" in keywords_df.columns:
            return keywords_df
    except Exception:
        pass

    try:
        with open("Milestone3_Keyword_Insights.csv", "r", encoding="utf-8") as f:
            content = f.read()
        if "=== KEYWORD FREQUENCY ===" in content:
            keyword_part = content.split("=== KEYWORD FREQUENCY===")[1].split(
                "=== PRODUCT SENTIMENT SUMMARY ==="
            )[0]
            keyword_part = keyword_part.strip().splitlines()
            if len(keyword_part) > 1:
                keywords_df = pd.read_csv(pd.StringIO("\n".join(keyword_part)))
                return keywords_df
    except Exception:
        pass

    return pd.DataFrame()

df = load_data()
keywords_df = load_keywords()


# ── Premium Login Page UI (Super Duper UI) ──
def login_page():
    st.markdown("""
        <style>
        [data-testid="collapsedControl"] {display: none;}
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap');
        html, body, [class*="css"] {font-family: 'Plus Jakarta Sans', sans-serif !important;}
        
        .login-container {
            display: flex; justify-content: center; align-items: center; height: 70vh;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.05); /* Subtler glass */
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(150, 150, 150, 0.2);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 1.5, 1])
    with col2:
        st.markdown(f'<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<h1 style="color:#1f77b4; font-size: 3rem; font-weight:700;">✨ ReviewSense</h1>', unsafe_allow_html=True)
        st.markdown('<p style="opacity:0.7; margin-bottom:20px;">Welcome back. Please login to continue.</p>', unsafe_allow_html=True)
        
        with st.form("login_form", border=False):
            user = st.text_input("Username", placeholder="admin")
            password = st.text_input("Password", type="password", placeholder="admin")
            submit = st.form_submit_button("Sign In →", use_container_width=True)
            if submit:
                if user == "admin" and password == "admin":
                    st.session_state["logged_in"] = True
                    st.session_state["username"] = user
                    st.rerun()
                else:
                    st.error("Invalid Credentials. Tip: Use admin/admin")
        st.markdown('</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

if not st.session_state["logged_in"]:
    login_page()
    st.stop()


# ── Navbar Integration ──
st.sidebar.markdown(f"## ✨ ReviewSense")
st.sidebar.markdown(f"**Hi, {st.session_state['username']}** 👋")
st.sidebar.markdown("---")

st.sidebar.markdown("**Navigation**")
page = st.sidebar.radio(
    "",
    options=["Dashboard", "Feedback Analyzer", "Insight Creator"],
    format_func=lambda x: {"Dashboard": "📊 Main Dashboard", "Feedback Analyzer": "💬 Live Analyzer", "Insight Creator": "💡 Insight Creator"}[x]
)

st.sidebar.markdown("---")
if st.sidebar.button("🚪 Logout", use_container_width=True):
    st.session_state["logged_in"] = False
    st.rerun()


# ── Page 1: USER'S DASHBOARD CODE ──
if page == "Dashboard":
    
    # User's Custom CSS for better look
    st.markdown(
        """
            <style>
            .main-header {
            font-size: 3rem;
            color: #1f77b4;
            text-align: center;
            margin-bottom: 2rem;
            }
            .metric-card {
            background-color: #f0f2f6;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }
            /* Add Dark Mode support for metric cards inherently */
            @media (prefers-color-scheme: dark) {
                .metric-card { background-color: #2b2b2b; color: white; }
            }
            </style>
    """,
        unsafe_allow_html=True,
    )

    # ── Sidebar Filters
    st.sidebar.header("🔍 Filters")
    # Sentiment
    sentiment_options = ["positive", "negative", "neutral"]
    sentiment_display = {"positive": "Positive", "negative": "Negative", "neutral": "Neutral"}
    sentiment_filter_display = st.sidebar.multiselect(
        "Select Sentiment",
        options=[sentiment_display[s] for s in sentiment_options],
        default=[sentiment_display[s] for s in sentiment_options],
    )
    sentiment_filter = [k for k, v in sentiment_display.items() if v in sentiment_filter_display]
    
    # Product
    product_options = sorted(df["product"].dropna().unique()) if "product" in df.columns else []
    product_filter = st.sidebar.multiselect(
        "Select Product",
        options=product_options,
        default=product_options,
    )
    
    # Date range
    st.sidebar.subheader("📅 Date Range")
    # Safe defaults
    if not df.empty and pd.notna(df["date"].min()):
        default_start = df["date"].min().date()
    else:
        default_start = datetime(2025, 1, 1).date()
    if not df.empty and pd.notna(df["date"].max()):
        default_end = df["date"].max().date()
    else:
        default_end = datetime(2025, 12, 31).date()
        
    col_d1, col_d2 = st.sidebar.columns(2)
    start_date = col_d1.date_input("Start Date", value=default_start)
    end_date = col_d2.date_input("End Date", value=default_end)

    # ── Apply Filters
    if not df.empty:
        filtered_df = df[
            (df["sentiment"].isin(sentiment_filter))
            & (df["product"].isin(product_filter))
            & (df["date"] >= pd.to_datetime(start_date))
            & (df["date"] <= pd.to_datetime(end_date))
        ].copy()  # .copy() avoids SettingWithCopyWarning later
    else:
        filtered_df = pd.DataFrame()

    # ── Main Dashboard
    st.markdown(
        '<h1 class="main-header">📊 ReviewSense – Customer Feedback Dashboard</h1>',
        unsafe_allow_html=True,
    )

    # Key Metrics
    col1, col2, col3, col4 = st.columns(4)
    total_reviews = len(filtered_df)
    pos_count = len(filtered_df[filtered_df["sentiment"] == "positive"]) if not filtered_df.empty else 0
    neg_count = len(filtered_df[filtered_df["sentiment"] == "negative"]) if not filtered_df.empty else 0
    neu_count = len(filtered_df[filtered_df["sentiment"] == "neutral"]) if not filtered_df.empty else 0
    
    pos_pct = (pos_count / total_reviews * 100) if total_reviews > 0 else 0
    neg_pct = (neg_count / total_reviews * 100) if total_reviews > 0 else 0
    neu_pct = (neu_count / total_reviews * 100) if total_reviews > 0 else 0
    
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Total Reviews", total_reviews)
        st.markdown("</div>", unsafe_allow_html=True)
    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Positive", f"{pos_pct:.1f}%", delta=f"{pos_count} reviews")
        st.markdown("</div>", unsafe_allow_html=True)
    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Negative", f"{neg_pct:.1f}%", delta=f"{neg_count} reviews")
        st.markdown("</div>", unsafe_allow_html=True)
    with col4:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("Neutral", f"{neu_pct:.1f}%", delta=f"{neu_count} reviews")
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Sentiment Distribution ──────────────────────────────────────────────────
    st.subheader("😊 Sentiment Distribution")
    if not filtered_df.empty:
        fig1, ax1 = plt.subplots(figsize=(8, 5))
        fig1.patch.set_alpha(0)  # transparent bg
        
        counts = filtered_df["sentiment"].value_counts()
        colors = {"positive": "#4CAF50", "negative": "#F44336", "neutral": "#9E9E9E"}
        bars = ax1.bar(
            [sentiment_display.get(s, s.title()) for s in counts.index],
            counts.values,
            color=[colors.get(s, "gray") for s in counts.index]
        )
        ax1.set_xlabel("Sentiment")
        ax1.set_ylabel("Number of Reviews")
        ax1.set_title("Overall Sentiment Breakdown")
        for bar in bars:
            yval = bar.get_height()
            ax1.text(
                bar.get_x() + bar.get_width() / 2,
                yval + (yval * 0.01),
                int(yval),
                ha="center",
                va="bottom",
            )
        st.pyplot(fig1)
    else:
        st.info("No data matches the selected filters.")

    # ── Product Sentiment ───────────────────────────────────────────────────────
    st.subheader("📱 Product-wise Sentiment")
    if not filtered_df.empty and "product" in filtered_df.columns:
        product_sent = (
            filtered_df.groupby("product")["sentiment"].value_counts().unstack(fill_value=0)
        )
        # Ensure all sentiment columns exist
        for col in sentiment_options:
            if col not in product_sent.columns:
                product_sent[col] = 0
        product_sent["Total"] = product_sent.sum(axis=1)
        product_sent["Positive %"] = (
            product_sent.get("positive", 0) / product_sent["Total"] * 100
        ).round(1)
        product_sent = product_sent.sort_values("Positive %", ascending=False)
        # Rename columns for display
        display_cols = [sentiment_display[s] for s in sentiment_options]
        product_sent_disp = product_sent.copy()
        product_sent_disp.rename(columns=sentiment_display, inplace=True)
        st.dataframe(product_sent_disp[display_cols + ["Total", "Positive %"]].style.format(precision=1), use_container_width=True)
        
        # Heatmap
        fig_hm, ax_hm = plt.subplots(figsize=(10, 6))
        fig_hm.patch.set_alpha(0)
        sns.heatmap(
            product_sent[sentiment_options],
            annot=True,
            fmt="d",
            cmap="RdYlGn",
            ax=ax_hm,
        )
        ax_hm.set_title("Product Sentiment Heatmap")
        st.pyplot(fig_hm)

    # ── Trend Over Time ─────────────────────────────────────────────────────────
    st.subheader("📈 Sentiment Trends Over Time")
    if not filtered_df.empty and pd.notna(filtered_df["date"].max()):
        filtered_df["month"] = filtered_df["date"].dt.to_period("M")
        trend = filtered_df.groupby(["month", "sentiment"]).size().unstack(fill_value=0)
        fig_trend, ax_trend = plt.subplots(figsize=(12, 6))
        fig_trend.patch.set_alpha(0)
        
        for col in trend.columns:
            ax_trend.plot(
                trend.index.astype(str), trend[col], marker="o", linewidth=2, label=col
            )
        ax_trend.set_xlabel("Month")
        ax_trend.set_ylabel("Number of Reviews")
        ax_trend.set_title("Monthly Sentiment Trend")
        ax_trend.legend()
        ax_trend.tick_params(axis="x", rotation=45)
        plt.tight_layout()
        st.pyplot(fig_trend)
    else:
        st.info("No date-based data available after filtering.")

    # ── Keywords ────────────────────────────────────────────────────────────────
    st.subheader("🔑 Top Keywords & Word Cloud")
    if not keywords_df.empty:
        top10 = keywords_df.head(15)
        colA, colB = st.columns([3, 2])
        with colA:
            fig_bar, ax_bar = plt.subplots(figsize=(10, 6))
            fig_bar.patch.set_alpha(0)
            ax_bar.barh(top10["keyword"], top10["frequency"], color="skyblue")
            ax_bar.set_xlabel("Frequency")
            ax_bar.set_title("Top Keywords")
            ax_bar.invert_yaxis()
            st.pyplot(fig_bar)
        with colB:
            if len(top10) > 0:
                word_freq = dict(zip(keywords_df["keyword"], keywords_df["frequency"]))
                try:
                    word_freq = {str(k): int(v) for k, v in word_freq.items()}
                    wc = WordCloud(
                        width=400, height=400, background_color="white", min_font_size=10
                    ).generate_from_frequencies(word_freq)
                    fig_wc, ax_wc = plt.subplots(figsize=(6, 6))
                    fig_wc.patch.set_alpha(0)
                    ax_wc.imshow(wc, interpolation="bilinear")
                    ax_wc.axis("off")
                    st.pyplot(fig_wc)
                except Exception:
                    pass

    # ── Confidence Score ────────────────────────────────────────────────────────
    st.subheader("📊 Confidence Score Distribution")
    if not filtered_df.empty and "confidence_score" in filtered_df.columns:
        fig_hist, ax_hist = plt.subplots(figsize=(10, 5))
        fig_hist.patch.set_alpha(0)
        ax_hist.hist(
            filtered_df["confidence_score"].dropna(),
            bins=25,
            color="cornflowerblue",
            edgecolor="black",
            alpha=0.7,
        )
        ax_hist.set_xlabel("Confidence Score (–1 to +1)")
        ax_hist.set_ylabel("Count")
        ax_hist.set_title("Sentiment Confidence Distribution")
        st.pyplot(fig_hist)

    # ── Data & Download ─────────────────────────────────────────────────────────
    st.write("---")
    st.subheader("💾 Export Data")
    
    col_dl1, col_dl2 = st.columns(2)
    with col_dl1:
        st.download_button(
            "⬇️ Download Filtered Reviews (CSV)",
            filtered_df.to_csv(index=False).encode("utf-8"),
            "ReviewSense_Filtered_Reviews.csv",
            "text/csv",
            use_container_width=True,
        )
    with col_dl2:
        if not keywords_df.empty:
            st.download_button(
                "⬇️ Download Keyword List (CSV)",
                keywords_df.to_csv(index=False).encode("utf-8"),
                "ReviewSense_Keywords.csv",
                "text/csv",
                use_container_width=True,
            )
            
    with st.expander("📋 Preview Filtered Data (first 15 rows)"):
        st.dataframe(filtered_df.head(15), use_container_width=True)

    st.success("✅ Dashboard ready! Use the sidebar to explore different views.")


# ── Page 2: Feedback Analyzer ──
elif page == "Feedback Analyzer":
    st.markdown('<h1 style="color:#1f77b4; font-weight:700;">Live Sentiment Analyzer 💬</h1>', unsafe_allow_html=True)
    st.markdown("Need to check a single review instantly? Our AI evaluates live feedback with polarity scoring.")
    
    f_input = st.text_area("✍️ Paste Text Here:", height=200, placeholder="The new update is absolutely fantastic, but the checkout process is a bit confusing...")
    
    colA, colB, colC = st.columns([1, 2, 1])
    with colB:
        analyze_btn = st.button("Run AI Analysis 🚀", use_container_width=True)
        
    if analyze_btn and f_input.strip():
        with st.spinner("Processing semantics..."):
            blob = TextBlob(f_input)
            score = blob.sentiment.polarity
            subjectivity = blob.sentiment.subjectivity
            
            if score > 0.1: sent, col = "Positive 😊", "#10B981"
            elif score < -0.1: sent, col = "Negative 😠", "#EF4444"
            else: sent, col = "Neutral 😐", "#6B7280"
            
            st.markdown(f"""
            <div style="background-color: {col}; color: white; padding: 30px; border-radius: 16px; margin-top:20px; text-align: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);">
                <h2 style="color: white !important; font-size: 2.5rem; font-weight: 800; margin: 0;">{sent}</h2>
                <div style="display: flex; justify-content: space-around; margin-top: 20px;">
                    <div><p style="margin:0; font-size: 0.9rem;">Polarity Score</p>
                    <h3 style="color: white !important; margin:0;">{score:.2f}</h3></div>
                    <div><p style="margin:0; font-size: 0.9rem;">Subjectivity</p>
                    <h3 style="color: white !important; margin:0;">{subjectivity:.2f}</h3></div>
                </div>
            </div>
            """, unsafe_allow_html=True)


# ── Page 3: Insight Creator ──
elif page == "Insight Creator":
    st.markdown('<h1 style="color:#1f77b4; font-weight:700;">Executive Insight Creator 💡</h1>', unsafe_allow_html=True)
    st.markdown("Automatically generate a downloadable text report summarizing the current state of customer satisfaction.")
    
    if st.button("Generate Executive Summary Report", type="primary"):
        with st.spinner("Compiling metrics..."):
            total_reviews = len(df)
            pos_reviews = len(df[df['sentiment'] == 'positive']) if not df.empty and 'sentiment' in df.columns else 0
            neg_reviews = len(df[df['sentiment'] == 'negative']) if not df.empty and 'sentiment' in df.columns else 0
            
            top_word = keywords_df.iloc[0]['keyword'] if not keywords_df.empty else "N/A"
            
            report = f"""
=========================================
      REVIEWSENSE EXECUTIVE REPORT       
=========================================
Date Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Total Reviews Processed: {total_reviews}
-----------------------------------------
SENTIMENT OVERVIEW:
- Positive Sentiment: {pos_reviews} ({(pos_reviews/total_reviews*100) if total_reviews else 0:.1f}%)
- Negative Sentiment: {neg_reviews} ({(neg_reviews/total_reviews*100) if total_reviews else 0:.1f}%)

KEY INSIGHTS:
- The most highly recurring keyword in customer feedback is "{top_word}".
- Based on the confidence scores, the model is highly certain of these categorizations.

RECOMMENDATIONS:
- Investigate the top negative keywords heavily to reduce churn.
- Leverage the positive features mentioned for future marketing.
=========================================
            """
            
            st.text_area("Preview Report", value=report, height=350)
            st.download_button("📥 Download Report (.txt)", data=report.encode('utf-8'), file_name="ReviewSense_Executive_Report.txt")
